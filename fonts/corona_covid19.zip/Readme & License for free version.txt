
PLEASE NOTE: THIS FONT IS FREE FOR PERSONAL USE NOT FOR COMMERCIAL PURPOSES

DOWNLOAD PREMIUM VERSION:
https://graphicriver.net/user/alifinart/portfolio/
https://behance.net/alifinart/

Extended Commercial License font please email me: alifinart@gmail.com	

BAHASA INDONESIA (PENTING UNTUK DIBACA):
Dear para desainer, agency, corporate, blogger, photographer, youtuber, instagramer dan para pengguna social media atau para pemilik usaha baik kecil maupun besar, saya informasikan sebelum anda menggunakan font karya saya, bahwa font yang saya upload disini adalah �free for personal use� (gratis untuk digunakan secara pribadi) dan bukan untuk tujuan komersil. Sekali lagi, bahwa anda bebas menggunakan font karya saya dengan tujuan pribadi, namun dilarang untuk digunakan untuk tujuan komersial, jualan, meraup keuntungan materi atau untuk meningkatkan profit bisnis, baik cetak maupun elektronik. 

Sebagai contoh untuk tujuan komersil adalah: untuk jualan, untuk keperluan branding, logo, videograpfi, film, video pendek, footage dan lain sebagainya yang dapat menghasilkan keuntungan materi dengan digunakannya font ini. 

Bagi siapa saja yang ingin menggunakan font saya untuk tujuan komersial/keuntungan materi silahkan menghubungi saya melalui email alifinart@gmail.com (ada harga istimewa khusus buat anda).

Dan bagi siapa saja yang menggunakan font dengan lisensi �Personal Use� untuk tujuan komersil, maka akan dikenakan biaya Extended License, yaitu 10 (sepuluh) kali lipat dari biaya Corporate License atau senilai IDR. 20.000.000.00,- (Dua puluh juta rupiah).

Atas perhatian dan supportnya yang baik, saya ucapkan terima kasih.

Alifinart

Copyright � 2020 Alifinart
